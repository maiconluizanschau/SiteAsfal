// English lang variables for WP2.5

tinyMCE.addI18n({en_US:{
WPSC:{	
desc :'Add a product shortcode'
}}});
