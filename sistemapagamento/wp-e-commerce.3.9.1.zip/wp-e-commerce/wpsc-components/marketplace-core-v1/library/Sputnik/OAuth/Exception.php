<?php

/* Generic exception class
 */
class Sputnik_OAuth_Exception extends Exception {
	// pass
}
