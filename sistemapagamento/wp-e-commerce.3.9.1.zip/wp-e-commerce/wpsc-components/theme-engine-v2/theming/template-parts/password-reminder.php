<?php wpsc_user_messages(); ?>
<div class="wpsc-password-reminder-form-wrapper">
	<?php wpsc_password_reminder_form(); ?>
</div>