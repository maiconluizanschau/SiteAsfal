<?php wpsc_checkout_steps(); ?>
<?php wpsc_user_messages(); ?>
<div class="wpsc-checkout wpsc-checkout-shipping-and-billing">
	<?php wpsc_checkout_form(); ?>
</div>