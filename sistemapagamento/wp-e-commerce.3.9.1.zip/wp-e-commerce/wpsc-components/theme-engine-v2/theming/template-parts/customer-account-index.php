<div class="wpsc-customer-account-index">
	<?php wpsc_customer_account_tabs(); ?>
	<?php wpsc_customer_orders_statuses(); ?>
	<?php wpsc_customer_orders_pagination(); ?>
	<?php wpsc_customer_orders_list(); ?>
	<?php wpsc_customer_orders_pagination(); ?>
</div>