<div class="wpsc-customer-account-digital-content">
	<?php wpsc_customer_account_tabs(); ?>
	<?php wpsc_customer_account_digital_contents(); ?>
</div>