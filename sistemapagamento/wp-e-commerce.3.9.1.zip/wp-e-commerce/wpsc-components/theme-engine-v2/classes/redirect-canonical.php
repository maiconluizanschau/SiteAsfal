<?php

class _WPSC_Redirect_Canonical {

}