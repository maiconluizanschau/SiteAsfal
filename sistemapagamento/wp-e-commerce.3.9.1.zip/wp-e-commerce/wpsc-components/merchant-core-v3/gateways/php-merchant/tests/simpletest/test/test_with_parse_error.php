<?php
    // $Id: test_with_parse_error.php 901 2005-01-24 00:32:14Z lastcraft $

    class TestCaseWithParseError extends UnitTestCase {
        //wibble
    }

?>